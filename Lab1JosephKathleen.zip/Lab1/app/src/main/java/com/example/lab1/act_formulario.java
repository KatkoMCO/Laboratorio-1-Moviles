package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class act_formulario extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    /*
    *
    * Hecho por:
    * Kathleen María Granados Corea
    * Joseph Ureña Rodríguez
    *
    * */

    EditText txtNombreAct, txtDescripcion, txtFechaLimiteAct, txtHora;
    Spinner spCategoria;
    Button btnAgregarTarea;
    String categoria;

    Tarea tarea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lyt_formulario);

        txtNombreAct = findViewById(R.id.txtNombreAct);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        txtFechaLimiteAct = findViewById(R.id.txtFechaLimiteAct);
        txtHora = findViewById(R.id.txtHora);

        spCategoria = findViewById(R.id.spCategoria);

        btnAgregarTarea = findViewById(R.id.btnAgregarTarea);




        ArrayAdapter<CharSequence> adapterSpinner = ArrayAdapter.createFromResource(this,
                R.array.spCategoriaFiltro, android.R.layout.simple_spinner_item);
            adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spCategoria.setAdapter(adapterSpinner);
            spCategoria.setOnItemSelectedListener(this);



        btnAgregarTarea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtNombreAct.getText().toString().isEmpty() || txtDescripcion.getText().toString().isEmpty() || txtFechaLimiteAct.getText().toString().isEmpty() ||
                    txtHora.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(), "Porfavor ingrese todos los datos", Toast.LENGTH_SHORT).show();
                }
                else{
                    String nombre =  txtNombreAct.getText().toString();
                    String descripcion = txtDescripcion.getText().toString();
                    String fechaLimite = txtFechaLimiteAct.getText().toString();
                    String hora = txtHora.getText().toString();

                    tarea = new Tarea(0, nombre, descripcion, fechaLimite, hora, categoria);
                    limpiar();
                    Toast.makeText(getApplicationContext(), "Tarea agregada correctamente", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(act_formulario.this, act_listaTareas.class);
                    intent.putExtra("tarea", tarea);
                    startActivity(intent);
                }
            }
        });
    }//fin oncreate




    public void limpiar(){
        txtNombreAct.setText("");
        txtDescripcion.setText("");
        txtFechaLimiteAct.setText("");
        txtHora.setText("");
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        categoria = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}//fin clase