package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOutOfMemoryException;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class act_listaTareas extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    /*
     *
     * Hecho por:
     * Kathleen María Granados Corea
     * Joseph Ureña Rodríguez
     *
     * */

    private static SQLiteDatabase db; //Se define la base de datos
    private static final String NOMBRE_BD = "MultiSQLite"; //Se define el nombre de la base de datos
    private final String TABLA_TAREA = "tarea"; //Se define el nombre de la tabla

    Button btnAgregar;
    ListView listaTareas;
    Spinner spCategoriaFiltro;
    String categoriaSeleccionada;


    Tarea tarea;
    Tarea tareaModificada;
    ArrayList<Tarea> listT;
    ArrayAdapter<Tarea> adapterT;

    //Crear tabla si no existe
    //Declaracion de variable que contiene consulta para crear tabla en caso de que no exista
    public static final String tbTarea = "CREATE TABLE IF NOT EXISTS tarea(id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "nombre STRING NOT NULL," + "descripcion STRING NOT NULL," + "fechaLimite STRING NOT NULL," + "hora STRING NOT NULL," + "categoria STRING NOT NULL);";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        abrirDataBase();

        setContentView(R.layout.lyt_lista_tareas);

        btnAgregar = findViewById(R.id.btnAgregar);

        listaTareas = findViewById(R.id.listaTareas);

        tarea = getIntent().getParcelableExtra("tarea");
        tareaModificada = getIntent().getParcelableExtra("tareaModificada");

        spCategoriaFiltro = findViewById(R.id.spCategoriaFiltro);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spCategoriaFiltro, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategoriaFiltro.setAdapter(adapter);
        spCategoriaFiltro.setOnItemSelectedListener(this);


        if(tareaModificada != null){
            updateTarea(tareaModificada);
        }

        if(tarea != null){
            addTarea(tarea);
        }

        if(getTarea() != null){
            listT = getTarea();
            adapterT = new ArrayAdapter<>(act_listaTareas.this, android.R.layout.simple_list_item_1, listT);
            listaTareas.setAdapter(adapterT);
        }

        //------------------------------------------------------------------------------------------

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(act_listaTareas.this, act_formulario.class);
                startActivity(intent);
            }
        });

        spCategoriaFiltro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                categoriaSeleccionada = adapterView.getItemAtPosition(i).toString();
                adapterT = new ArrayAdapter<>(act_listaTareas.this, android.R.layout.simple_list_item_1, getListaFiltrada(categoriaSeleccionada, getTarea()));
                listaTareas.setAdapter(adapterT);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        listaTareas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(act_listaTareas.this, act_modificarLista.class);
                intent.putExtra("tarea", getTarea().get(i));
                startActivity(intent);
            }
        });

    }//FIN ONCREATE

    //--------------------------------------------------------------------------------------------------

    public void abrirDataBase() {
        try {
            db = openOrCreateDatabase(NOMBRE_BD, MODE_PRIVATE, null);
            db.execSQL(tbTarea);
        } catch (SQLiteOutOfMemoryException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Error al crear la base de datos", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean addTarea(Tarea tarea){
        //diccionario o contenedor que almacena pares de clave - valor, los nombres de las columnas y valores a almacenar en la bd
        ContentValues content = new ContentValues();
        content.put("nombre", tarea.getNombre());
        content.put("descripcion", tarea.getDescripcion());
        content.put("fechaLimite", tarea.getFechaLimite());
        content.put("hora", tarea.getHora());
        content.put("categoria", tarea.getCategoria());


        return db.insert(TABLA_TAREA, null, content) > 0;
    }//fin addTarea

    private ArrayList<Tarea> getTarea(){
        Cursor cursor = db.query(TABLA_TAREA, new String[]{"id", "nombre", "descripcion", "fechaLimite", "hora", "categoria"},
                null, null, null, null, "id desc");

        cursor.moveToFirst();//se mueve el cursor al primer registro

        //recorrerlo
        ArrayList<Tarea> listaT = new ArrayList<>();

        while (!cursor.isAfterLast()){
            Tarea tarea = new Tarea();
            tarea.setId(cursor.getInt(0));
            tarea.setNombre(cursor.getString(1));
            tarea.setDescripcion(cursor.getString(2));
            tarea.setFechaLimite(cursor.getString(3));
            tarea.setHora(cursor.getString(4));
            tarea.setCategoria(cursor.getString(5));

            listaT.add(tarea);
            cursor.moveToNext();
        }//fin while

        cursor.close();
        return listaT;
    }//Fin getTarea

    private boolean updateTarea(Tarea tarea){
        ContentValues content = new ContentValues();
        content.put("nombre", tarea.getNombre());
        content.put("descripcion", tarea.getDescripcion());
        content.put("fechaLimite", tarea.getFechaLimite());
        content.put("hora", tarea.getHora());
        content.put("categoria", tarea.getCategoria());
        return db.update(TABLA_TAREA, content, "id=" + tarea.getId(), null) > 0;
    }//fin updateTarea

    public ArrayList<Tarea> getListaFiltrada(String categoria, ArrayList<Tarea> lista){
        ArrayList<Tarea> listaFiltrada = new ArrayList<>();
        if(categoria.equalsIgnoreCase("Categorias")){
            listaFiltrada = lista;
        }
        else{
            for (int i = 0; i < lista.size(); i++)
            {
                if(lista.get(i).getCategoria().equalsIgnoreCase(categoria)){
                    listaFiltrada.add(lista.get(i));
                }
            }
        }
        return  listaFiltrada;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}//FIN CLASE