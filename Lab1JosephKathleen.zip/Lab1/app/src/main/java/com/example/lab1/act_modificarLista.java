package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class act_modificarLista extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    /*
     *
     * Hecho por:
     * Kathleen María Granados Corea
     * Joseph Ureña Rodríguez
     *
     * */

    EditText txtNombre, txtDescripcion, txtFechaLimite, txtHora;
    Spinner spCategoria;
    Button btnModificar;
    String categoria;

    Tarea tarea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lyt_modificar_lista);

        txtNombre = findViewById(R.id.txtNombreM);
        txtDescripcion = findViewById(R.id.txtDescripcionM);
        txtFechaLimite = findViewById(R.id.txtFechaLimiteM);
        txtHora = findViewById(R.id.txtHoraM);

        spCategoria = findViewById(R.id.spCategoriaM);

        btnModificar = findViewById(R.id.btnModificar);


        ArrayAdapter<CharSequence> adapterSpinner = ArrayAdapter.createFromResource(this,
                R.array.spCategoriaFiltro, android.R.layout.simple_spinner_item);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategoria.setAdapter(adapterSpinner);
        spCategoria.setOnItemSelectedListener(this);


        tarea = getIntent().getParcelableExtra("tarea");

        txtNombre.setText(tarea.getNombre());
        txtDescripcion.setText(tarea.getDescripcion());
        txtFechaLimite.setText(tarea.getFechaLimite());
        txtHora.setText(tarea.getHora());

        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtNombre.getText().toString().isEmpty() || txtDescripcion.getText().toString().isEmpty() || txtFechaLimite.getText().toString().isEmpty() ||
                        txtHora.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(), "Porfavor ingrese todos los datos", Toast.LENGTH_SHORT).show();
                }
                else{
                    String nombre =  txtNombre.getText().toString();
                    String descripcion = txtDescripcion.getText().toString();
                    String fechaLimite = txtFechaLimite.getText().toString();
                    String hora = txtHora.getText().toString();

                    tarea = new Tarea(tarea.getId(), nombre, descripcion, fechaLimite, hora, categoria);

                    Toast.makeText(getApplicationContext(), "Tarea modificada correctamente", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(act_modificarLista.this, act_listaTareas.class);
                    intent.putExtra("tareaModificada", tarea);
                    startActivity(intent);
                }
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        categoria = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}