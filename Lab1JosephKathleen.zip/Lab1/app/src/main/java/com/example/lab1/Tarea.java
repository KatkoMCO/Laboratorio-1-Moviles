package com.example.lab1;

import android.os.Parcel;
import android.os.Parcelable;

public class Tarea implements Parcelable {

    /*
     *
     * Hecho por:
     * Kathleen María Granados Corea
     * Joseph Ureña Rodríguez
     *
     * */

    private int id;
    private String nombre, descripcion, fechaLimite, hora, categoria;

    public Tarea(int id, String nombre, String descripcion, String fechaLimite, String hora, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.hora = hora;
        this.categoria = categoria;
    }

    public Tarea() {
        this.id = 0;
        this.nombre = "";
        this.descripcion = "";
        this.fechaLimite = "";
        this.hora = "";
        this.categoria = "";
    }


    protected Tarea(Parcel in) {
        id = in.readInt();
        nombre = in.readString();
        descripcion = in.readString();
        fechaLimite = in.readString();
        hora = in.readString();
        categoria = in.readString();
    }

    public static final Creator<Tarea> CREATOR = new Creator<Tarea>() {
        @Override
        public Tarea createFromParcel(Parcel in) {
            return new Tarea(in);
        }

        @Override
        public Tarea[] newArray(int size) {
            return new Tarea[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(String fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "ID:" + id +
                "\nNombre: '" + nombre + '\'' +
                "\nDescripción: '" + descripcion + '\'' +
                "\nFecha Límite: '" + fechaLimite + '\'' +
                "\nHora: '" + hora + '\'' +
                "\nCategoría: '" + categoria;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(nombre);
        parcel.writeString(descripcion);
        parcel.writeString(fechaLimite);
        parcel.writeString(hora);
        parcel.writeString(categoria);
    }
}
